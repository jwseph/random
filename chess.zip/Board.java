public class Board {
    private final int nr = 8, nc = 8;
    private final Piece[][] grid;
    public int moves = 0;
    public Board() {
        grid = new Piece[nr][nc];
        grid[0][3] = new King(this, 0, 3, true);
        grid[7][3] = new King(this, 7, 3, false);
        grid[0][4] = new Queen(this, 0, 4, true);
        grid[7][4] = new Queen(this, 7, 4, false);
        for (int c = 0; c < 8; c++) {
            grid[1][c] = new Pawn(this, 1, c, true);
            grid[6][c] = new Pawn(this, 6, c, false);
        }
        for (int c = 0; c < 8; c += 7) {
            grid[0][c] = new Rook(this, 0, c, true);
            grid[7][c] = new Rook(this, 7, c, false);
        }
        for (int c = 1; c < 7; c += 5) {
            grid[0][c] = new Knight(this, 0, c, true);
            grid[7][c] = new Knight(this, 7, c, false);
        }
        for (int c = 2; c < 6; c += 3) {
            grid[0][c] = new Bishop(this, 0, c, true);
            grid[7][c] = new Bishop(this, 7, c, false);
        }
    }
    public Board(Board b) {
        moves = b.moves;
        grid = new Piece[nr][nc];
        for (int r = 0; r < nr; r++) {
            for (int c = 0; c < nc; c++) {
                if (b.grid[r][c] == null) continue;
                grid[r][c] = b.grid[r][c].copy(this);
            }
        }
    }
    public boolean isEmpty(int r, int c) { return grid[r][c] == null; }
    public boolean isEmpty(Position p) { return isEmpty(p.r, p.c); }
    public Piece get(int r, int c) { return grid[r][c]; }
    public Piece get(Position p) { return get(p.r, p.c); }
    public void move(int r, int c, Position move) {
        move(r, c, move.r, move.c);
    }
    public void move(int r, int c, int nr, int nc) {
        // Enable en passant for pawn
        if (grid[r][c] instanceof Pawn && !grid[r][c].hasMoved() && (nr-r)*(nr-r) == 4) {
            ((Pawn)grid[r][c]).setEnPassant(moves+1);
        }
        // En passant take
        if (grid[r][c] instanceof Pawn && c != nc && grid[nr][nc] == null) {
            grid[r][nc] = null;
        }
        // Castling
        if (grid[r][c] instanceof King && !grid[r][c].hasMoved()) {
            if (nc == 1) move(r, 0, r, 2);
            if (nc == 5) move(r, 7, r, 4);
        }
        grid[r][c].setMoved();
        grid[r][c].r = nr;
        grid[r][c].c = nc;
        grid[nr][nc] = grid[r][c];
        grid[r][c] = null;
        // Promotion
        if (grid[nr][nc] instanceof Pawn && nr == (grid[nr][nc].isColor(true) ? 7 : 0)) {
            grid[nr][nc] = new Queen(this, nr, nc, grid[nr][nc].isColor(true));
        }
        moves++;
    }
    public boolean checkmate() {
        return canWin(!currentPlayer()) && !hasAllowedMoves();
    }
    public boolean hasAllowedMoves() {
        for (int r = 0; r < nr; ++r) {
            for (int c = 0; c < nc; ++c) {
                if (grid[r][c] == null || !grid[r][c].isColor(currentPlayer())) continue;
                if (!grid[r][c].getAllowedMoves().isEmpty()) return true;
            }
        }
        return false;
    }
    public boolean currentPlayer() {
        return moves%2 == 0;
    }
    public boolean canWin(boolean player) {
        for (int r = 0; r < nr; r++) {
            for (int c = 0; c < nc; c++) {
                if (grid[r][c] == null || !grid[r][c].isColor(player)) continue;
                for (Position move: grid[r][c].getMoves()) {
                    Piece take = get(move);
                    if (take == null) continue;
                    if (take instanceof King && take.isColor(!player)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    public String toString() {
        String bar = "+";
        for (int i = 0; i < 23; ++i) bar += "-";
        bar += "+\n";
        String res = "";
        res += bar;
        for (int r = 0; r < 8; ++r) {
            res += "|";
            for (int c = 0; c < 7; ++c) {
                res += grid[r][c] != null ? grid[r][c]+" " : ".  ";
            }
            res += grid[r][7] != null ? grid[r][7]+"" : ". ";
            res += "|\n";
        }
        res += bar;
        return res;
    }
}