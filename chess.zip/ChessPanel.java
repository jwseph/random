import javax.swing.*;
import javax.imageio.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import java.util.List;
import java.io.*;

public class ChessPanel extends JPanel implements MouseListener {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        System.setProperty("sun.java2d.uiScale", "1.0");
        JFrame frame = new JFrame("Chess");
        JPanel p = new ChessPanel();
        frame.add(p);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setVisible(true);
        p.repaint();
    }
    private Map<String, BufferedImage> textures = new HashMap<>();
    private final Color selectColor = new Color(0f, .4f, .3f, .4f);
    private final Color previousColor = new Color(.5f, .6f, 0f, .4f);
    private final int nr = 8, nc = 8;
    private int size, gap, gap2, width, height;
    private Piece selected = null;
    private Position prev1 = null, prev2 = null;
    private Board b = new Board();
    private boolean player = true, gameOver = false;
    public ChessPanel() throws FileNotFoundException, IOException {
        this(96);
    }
    public ChessPanel(int size) throws FileNotFoundException, IOException {
        this.size = size;
        gap = size/3;
        gap2 = size/4;
        height = nr*size;
        width = nc*size;
        setPreferredSize(new Dimension(width, height));
        addMouseListener(this);
        setFocusable(true);
        // Load images
        for (int r = 0; r < nr; ++r) {
            for (int c = 0; c < nc; ++c) {
                if (b.isEmpty(r, c)) continue;
                String s = b.get(r, c)+"";
                if (textures.containsKey(s)) continue;
                textures.put(s, ImageIO.read(new File("pieces/"+s+".png")));
            }
        }
    }
    @Override
    public void paintComponent(Graphics g) {
        ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        for (int r = 0; r < nr; r++) {
            for (int c = 0; c < nc; c++) {
                g.setColor((r+c)%2 == 0 ? new Color(240, 217, 181) : new Color(181, 136, 99));
                g.fillRect(c*size, r*size, size, size);
            }
        }
        if (prev1 != null) {
            g.setColor(previousColor);
            g.fillRect(tf(prev1.c)*size, tf(prev1.r)*size, size, size);
            g.fillRect(tf(prev2.c)*size, tf(prev2.r)*size, size, size);
        }
        if (selected != null) {
            g.setColor(selectColor);
            g.fillRect(tf(selected.c)*size, tf(selected.r)*size, size, size);
            for (Position move: selected.getAllowedMoves()) {
                int offX = tf(move.c)*size, offY = tf(move.r)*size;
                if (!b.isEmpty(move)) {
                    g.fillPolygon(new int[]{offX, offX+gap2, offX}, new int[]{offY, offY, offY+gap2}, 3);
                    g.fillPolygon(new int[]{offX+size, offX+size-gap2, offX+size}, new int[]{offY, offY, offY+gap2}, 3);
                    g.fillPolygon(new int[]{offX, offX+gap2, offX}, new int[]{offY+size, offY+size, offY+size-gap2}, 3);
                    g.fillPolygon(new int[]{offX+size, offX+size-gap2, offX+size}, new int[]{offY+size, offY+size, offY+size-gap2}, 3);
                    continue;
                }
                g.fillOval(offX+gap, offY+gap, size-gap*2, size-gap*2);
            }
        }
        for (int r = 0; r < nr; r++) {
            for (int c = 0; c < nc; c++) {
                Piece p = b.get(r, c);
                if (p == null) continue;
                g.drawImage(textures.get(p+""), tf(c)*size, tf(r)*size, size, size, null);
            }
        }
    }
    private void click(int r, int c) {
        Piece newPiece = b.get(r, c);
        // Unselect
        if (newPiece == selected) {
            selected = null;
            return;
        }
        // Select
        if (newPiece != null && newPiece.isColor(player)) {
            selected = newPiece;
            return;
        }
        if (selected == null) return;
        // Move/take piece
        if (selected.hasMove(new Position(r, c))) {
            prev1 = new Position(selected.r, selected.c);
            prev2 = new Position(r, c);
            b.move(selected.r, selected.c, r, c);
            selected = null;
            if (b.checkmate()) {
                System.out.println("Checkmate");
                gameOver = true;
            }
            if (!b.hasAllowedMoves()) {
                System.out.println("Stalemate");
                gameOver = true;
            }
            player = !player;
            return;
        }
        // Unselect
        selected = null;
    }
    private int tf(int s) {
        return transform(s);
    }
    private int transform(int s) {
        return player ? 7-s : s;
    }
    @Override
    public void mousePressed(MouseEvent me) {
        if (gameOver) return;
        click(tf(me.getY()/size), tf(me.getX()/size));
        repaint();
    }
    @Override
    public void mouseClicked(MouseEvent me) {}
    @Override
    public void mouseEntered(MouseEvent me) {}
    @Override
    public void mouseExited(MouseEvent me) {}        
    @Override
    public void mouseReleased(MouseEvent me) {}
}
