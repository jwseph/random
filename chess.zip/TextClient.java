public class TextClient {
    public static void main(String[] args) {
        Board b = new Board();
        System.out.println(b);
    }
}