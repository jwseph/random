public class Position {
    public int r, c;
    public Position(int r, int c) {
        this.r = r;
        this.c = c;
    }
    public boolean exists() {
        return 0 <= r && r < 8 && 0 <= c && c < 8;
    }
    public boolean equals(Position o) {
        return r == o.r && c == o.c;
    }
}
