import java.util.*;

public abstract class Piece {
    protected Board b;
    public int r, c;
    protected boolean w;
    protected boolean moved = false;
    public Piece(Board b, int r, int c, boolean w) {
        this.b = b;
        this.r = r;
        this.c = c;
        this.w = w;
    }
    protected abstract List<Position> generateMoves();
    public abstract Piece copy(Board b);
    protected void generateLine(List<Position> moves, int dr, int dc) {
        Position p = new Position(r+dr, c+dc);
        for (int i = 1; p.exists() && (b.get(p) == null || !b.get(p).isColor(w)); i++) {
            moves.add(p);
            if (b.get(p) != null && b.get(p).isColor(!w)) break;
            p = new Position(r+dr*(i+1), c+dc*(i+1));
        }
    }
    public List<Position> getMoves() {
        List<Position> moves = generateMoves();
        for (int i = moves.size()-1; i >= 0; i--) {
            Position move = moves.get(i);
            // TODO: FILTER MOVES THAT WOULD ALLOW CHECKMATE
            // ALSO ADD STALEMATE
            // Optional: Add dragging pieces
            if (!move.exists() || b.get(move) != null && b.get(move).isColor(w)) {
                moves.remove(i);
            }
        }
        return moves;
    }
    public List<Position> getAllowedMoves() {  // getMoves + no king sacrifice
        List<Position> moves = getMoves();
        for (int i = moves.size()-1; i >= 0; i--) {
            Board fb = new Board(b);
            fb.move(r, c, moves.get(i));
            if (fb.canWin(fb.currentPlayer())) {
                moves.remove(i);
            }
        }
        return moves;
    }
    public boolean hasMove(Position p) {
        for (Position move: getAllowedMoves()) {
            if (p.equals(move)) return true;
        }
        return false;
    }
    public boolean isColor(boolean w) {
        return this.w == w;
    }
    public String toString() {
        return "?"+(this.w?"w":"b");
    }
    public boolean hasMoved() {
        return moved;
    }
    public void setMoved() {
        moved = true;
    }
}