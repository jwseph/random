import java.util.*;

public class Knight extends Piece {
    public Knight(Board b, int r, int c, boolean w) {
        super(b, r, c, w);
    }
    public Piece copy(Board b) {
        Piece p = new Knight(b, r, c, w);
        p.moved = moved;
        return p;
    }
    public List<Position> generateMoves() {
        List<Position> moves = new ArrayList<>();
        for (int dr = 1; dr <= 2; dr++) {
            int dc = 3-dr;
            for (int mr = -1; mr <= 1; mr += 2) {
                for (int mc = -1; mc <= 1; mc += 2) {
                    moves.add(new Position(r+mr*dr, c+mc*dc));
                }
            }
        }
        return moves;
    }
    public String toString() {
        return "N"+(this.w?"w":"b");
    }
}