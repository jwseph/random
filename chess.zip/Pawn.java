import java.util.*;

public class Pawn extends Piece {
    private int enPassantIndex = -1;
    public Pawn(Board b, int r, int c, boolean w) {
        super(b, r, c, w);
    }
    public Piece copy(Board b) {
        Pawn p = new Pawn(b, r, c, w);
        p.moved = moved;
        p.enPassantIndex = enPassantIndex;
        return p;
    }
    public List<Position> generateMoves() {
        List<Position> moves = new ArrayList<>();
        int dr = w ? 1 : -1;
        Position fw = new Position(r+dr, c);
        if (fw.exists() && b.isEmpty(fw)) {
            moves.add(fw);
            if (w && r == 1 || !w && r == 6) {
                Position fw2 = new Position(2*dr+r, c);
                if (fw2.exists() && b.isEmpty(fw2)) {
                    moves.add(fw2);
                }
            }
        }
        Position tl = new Position(r+dr, c-1), tr = new Position(r+dr, c+1);
        if (tl.exists() && !b.isEmpty(tl)) moves.add(tl);
        if (tr.exists() && !b.isEmpty(tr)) moves.add(tr);
        // En passant
        if (c-1 >= 0 && b.get(r, c-1) != null && b.get(r, c-1) instanceof Pawn && ((Pawn)b.get(r, c-1)).canEnPassant()) {
            moves.add(new Position(r+dr, c-1));
        }
        if (c+1 < 8 && b.get(r, c+1) != null && b.get(r, c+1) instanceof Pawn && ((Pawn)b.get(r, c+1)).canEnPassant()) {
            moves.add(new Position(r+dr, c+1));
        }
        return moves;
    }
    public String toString() {
        return "P"+(this.w?"w":"b");
    }
    public void setEnPassant(int enPassant) {
        enPassantIndex = enPassant;
    }
    public boolean canEnPassant() {
        return b.moves == enPassantIndex;
    }
}
