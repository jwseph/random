import java.util.*;

public class King extends Piece {
    public King(Board b, int r, int c, boolean w) {
        super(b, r, c, w);
    }
    public Piece copy(Board b) {
        Piece p = new King(b, r, c, w);
        p.moved = moved;
        return p;
    }
    public List<Position> generateMoves() {
        List<Position> moves = new ArrayList<>();
        for (int dr = -1; dr <= 1; dr++) {
            for (int dc = -1; dc <= 1; dc++) {
                if (dr == 0 && dc == 0) continue;
                moves.add(new Position(r+dr, c+dc));
            }
        }
        if (!hasMoved()) {  // Castling
            if (b.isEmpty(r, 2) && b.isEmpty(r, 1)) {
                addCastlingMove(moves, new Position(r, 1), new Position(r, 0));
            }
            if (b.isEmpty(r, 6) && b.isEmpty(r, 5) && b.isEmpty(r, 4)) {
                addCastlingMove(moves, new Position(r, 5), new Position(r, 7));
            }   
        }
        return moves;
    }
    private void addCastlingMove(List<Position> moves, Position newKingPos, Position rookPos) {
        if (!b.isEmpty(rookPos) && b.get(rookPos) instanceof Rook && !b.get(rookPos).hasMoved()) {
            moves.add(newKingPos);
        }
    }
    public String toString() {
        return "K"+(this.w?"w":"b");
    }
}